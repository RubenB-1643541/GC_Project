here is the cool cool mountain slide,ripped by me
if you use this please give credit to alec pike
if you have any comments, complaints or compliments 
please contact me at alec.pike@gmail.com