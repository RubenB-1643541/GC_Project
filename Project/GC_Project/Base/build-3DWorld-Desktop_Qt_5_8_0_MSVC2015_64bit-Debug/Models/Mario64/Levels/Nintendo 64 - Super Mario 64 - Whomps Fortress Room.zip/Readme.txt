Here is the room for whomp's fortress from mario 64
If you use this could you give credit to me, Alec Pike
If you have a request or need help with the model e-mail me at alec.pike@gmail.com
