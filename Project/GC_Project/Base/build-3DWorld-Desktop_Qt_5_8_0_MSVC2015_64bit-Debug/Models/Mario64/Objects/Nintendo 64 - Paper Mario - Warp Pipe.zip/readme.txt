==--==--==--==--==--== Paper Mario Model ==--==--==--==--==--==

		Objects: Warp Pipe

		Ripped by MasterGamePro

===============================================================

The object is saved as an .obj file, but it is unique because
it preserves the vertex colors from the original game. Each 
vertex line has three additional double values to parse; these 
are the RGB values of the vertex. Please keep this in mind when
you use the model--if you are getting errors, your .obj loader
might not support vertex colors.

The texture is located inside the Textures folder. If you
use any of my other models, then extract them into the same
folder. The textures are shared among them to prevent 
redundancy.

This model is free to use, but please provide credit.